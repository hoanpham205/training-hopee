class CreateOrder < ActiveRecord::Migration[7.1]
  def change
    create_table :orders do |t|
      t.decimal :price 
      t.integer :qualitity
      
      t.timestamps
    end
  end
end
