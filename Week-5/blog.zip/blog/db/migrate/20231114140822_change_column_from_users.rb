class ChangeColumnFromUsers < ActiveRecord::Migration[7.1]
  def change
    change_column_null :users, :name , false
    change_column_default :users , :sex, from: true, to: false
  end
end
