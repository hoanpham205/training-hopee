class CreateJoinTableUsersOrder < ActiveRecord::Migration[7.1]
  def change
    create_join_table :users, :orders do |t|
      t.index :user_id
      t.index :order_id
    end
  end
end
